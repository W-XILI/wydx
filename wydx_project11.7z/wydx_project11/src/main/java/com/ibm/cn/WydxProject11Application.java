package com.ibm.cn;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WydxProject11Application {

	public static void main(String[] args) {
		SpringApplication.run(WydxProject11Application.class, args);
	}

}
