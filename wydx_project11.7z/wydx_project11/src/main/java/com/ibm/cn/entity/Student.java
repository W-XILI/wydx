package com.ibm.cn.entity;

public class Student {
	private String sName;
	private Integer age;
	
}
